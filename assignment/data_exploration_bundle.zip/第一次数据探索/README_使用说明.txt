Python《第一次数据探索》完整作业

1. 提交文件
- 第一次数据探索_完整作业.ipynb：已执行的 Notebook，含中文解释、代码、输出和9张图。
- 第一次数据探索_作业报告.docx：Word报告，含真实运行表格、9张图和中文注释代码附录。
请自行填写报告首页的姓名、学号、班级，并按老师要求调整格式。

2. 查看与复现
Notebook 的结果已经保存，不重新执行也可以查看。
重新运行时，先将整个压缩包解压，保持 data 文件夹与 Notebook 同级。
使用 Python 3.10+（本次实际运行 Python 3.12），安装依赖：
python -m pip install -r requirements.txt
在 Jupyter 或 VS Code 中打开 Notebook，并从上到下运行所有单元格。
Jupyter 的工作目录必须是本文件所在目录；可在首格检查 Path.cwd()。
Jupyter/VS Code 编辑界面需另行安装；requirements.txt 包含内核和分析依赖。

3. 数据与图表
B 使用 Palmer Penguins 真实资料；C 使用 Kaggle Titanic train.csv 的公开教学镜像。
具体来源、处理口径和文件SHA-256见 Notebook 的开头及 data/数据来源.json。
数据已包含，不需要 Kaggle 登录，不需要在线下载。
中文字体随附，许可见 data/Noto字体许可证.txt。
figures 文件夹包含9张180 dpi图，可直接用于作业。

4. 重要口径
A 中 N(100,15) 的第二个参数是标准差，不是方差。
检测到全部5个人工异常，同时有4个正态尾部点被IQR标记。
B 的异常筛查结果为0，不伪造异常值；清理后分析342条企鹅记录。
C 只做EDA，不训练模型。年龄缺失者另行统计，舱号不猜测填补。
D 是9种潜在电商质量问题及方案，不是虚构电商统计结果。

5. 可选：重新生成 Word
build_assignment.py 是交付构建脚本；它会运行全部Notebook代码，再同步生成Word。
该脚本默认使用当前文件夹内 .venv/bin/python（Linux/macOS）。
可先执行 python -m venv --system-site-packages .venv，
再执行 .venv/bin/python -m pip install -r requirements.txt，
最后执行 .venv/bin/python build_assignment.py。
Windows 使用者可直接学习运行 Notebook；如运行构建脚本，请将其中内核路径改为自己的虚拟环境Python路径。
