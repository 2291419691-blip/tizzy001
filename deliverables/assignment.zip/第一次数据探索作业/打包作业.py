"""打包完整成果并核验压缩包，排除缓存和虚拟环境。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
excluded = {'.cache', '__pycache__', '.venv', '.git'}
files = sorted(p for p in ROOT.rglob('*') if p.is_file()
               and not excluded.intersection(p.relative_to(ROOT).parts)
               and p.name != '文件校验清单.json')
assert files and all(p.stat().st_size > 0 for p in files)
manifest = {str(p.relative_to(ROOT)): {'字节数': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
manifest_path = ROOT/'文件校验清单.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
files.append(manifest_path)
archive = ROOT.parent / (ROOT.name + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files: z.write(p, arcname=str(Path(ROOT.name)/p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist()) == len(files)
    for name, info in manifest.items():
        content = z.read(str(Path(ROOT.name)/name))
        assert len(content) == info['字节数']
        assert hashlib.sha256(content).hexdigest() == info['sha256']
print(json.dumps({'压缩包':str(archive),'文件数量':len(files),'字节数':archive.stat().st_size,
                  '完整性检查':'ZIP CRC与逐文件SHA-256均通过'}, ensure_ascii=False, indent=2))
