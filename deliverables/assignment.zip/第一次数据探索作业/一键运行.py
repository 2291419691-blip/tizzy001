"""按依赖顺序执行全部分析、报告和验证；任何一步失败立即停止。"""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
logs = ROOT / '运行记录'
logs.mkdir(exist_ok=True)
steps = [('A', 'A_异常值检测/A_异常值检测.py'),
         ('B', 'B_真实数据EDA/B_数据探索.py'),
         ('C', 'C_Titanic数据探索/C_Titanic数据探索.py'),
         ('Word', '生成Word报告.py'), ('验证', '验证成果.py')]
for name, script in steps:
    print(f'正在运行：{script}', flush=True)
    result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (logs / f'{name}.log').write_text(result.stdout, encoding='utf-8')
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    print(f'{name}：成功；完整日志见运行记录/{name}.log', flush=True)
print('全部分析、Word报告和成果验证均成功。')
