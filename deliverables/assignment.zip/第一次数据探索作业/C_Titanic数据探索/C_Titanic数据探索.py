"""C：Titanic 训练集，仅探索性分析，不训练模型。"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 公共工具 import 设置绘图, 保存图, 保存表, 保存结果, 保存概况
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
设置绘图()
df = pd.read_csv(ROOT / 'train.csv')
expected = ['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp', 'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked']
assert df.shape == (891, 12) and df.columns.tolist() == expected
assert set(df.Survived.unique()) == {0, 1} and df.PassengerId.is_unique
assert set(df.Pclass.unique()) == {1, 2, 3} and (df.Fare >= 0).all()
保存概况(df, ROOT / '数据概况.txt')
保存表(df.head(), ROOT / '前五行.csv', index=False)
保存表(df.describe(include='all').T, ROOT / '描述性统计.csv')
missing = pd.DataFrame({'缺失数': df.isna().sum(), '缺失率%': df.isna().mean() * 100})
保存表(missing, ROOT / '所有字段缺失统计.csv')

def 生存汇总(frame, by):
    result = frame.groupby(by, observed=True)['Survived'].agg(样本数='size', 生存人数='sum', 生存率='mean')
    result['死亡人数'] = result['样本数'] - result['生存人数']
    result['生存率%'] = result['生存率'] * 100
    return result[['样本数', '生存人数', '死亡人数', '生存率', '生存率%']]

sex = 生存汇总(df, 'Sex')
pclass = 生存汇总(df, 'Pclass')
joint = 生存汇总(df, ['Pclass', 'Sex'])
eda = df.copy()
labels = ['0—11岁', '12—17岁', '18—34岁', '35—59岁', '60岁及以上']
eda['年龄组'] = pd.cut(eda.Age, bins=[0, 12, 18, 35, 60, np.inf], labels=labels, right=False)
age = 生存汇总(eda.dropna(subset=['Age']), '年龄组')
unknown = df.loc[df.Age.isna()]
age_unknown = pd.DataFrame({'样本数': [len(unknown)], '生存人数': [int(unknown.Survived.sum())],
 '死亡人数': [int((1-unknown.Survived).sum())], '生存率': [unknown.Survived.mean()],
 '生存率%': [unknown.Survived.mean()*100]}, index=['年龄缺失'])
overall = pd.DataFrame({'样本数': [len(df)], '生存人数': [int(df.Survived.sum())],
 '死亡人数': [int((1-df.Survived).sum())], '生存率': [df.Survived.mean()],
 '生存率%': [df.Survived.mean()*100]}, index=['全体'])
tables = [('总体', overall), ('性别', sex), ('舱位', pclass), ('年龄组', age), ('年龄缺失', age_unknown)]
merged = []
for name, table in tables:
    保存表(table, ROOT / f'{name}生存统计.csv')
    temp = table.rename_axis('分组').reset_index()
    temp.insert(0, '分组维度', name)
    merged.append(temp)
保存表(pd.concat(merged, ignore_index=True), ROOT / '统计结果.csv', index=False)
保存表(joint, ROOT / '性别与舱位交叉生存统计.csv')

# 1. 分组柱状图直接比较各性别生存和死亡人数，表格另给出分母与比率。
fig, ax = plt.subplots(figsize=(8, 5))
sex[['死亡人数', '生存人数']].rename(index={'female': '女性', 'male': '男性'}).plot.bar(
    ax=ax, color=['#bd6969', '#4c99b6'], rot=0)
for container in ax.containers: ax.bar_label(container, padding=3)
ax.set(xlabel='性别', ylabel='人数', title='C1：不同性别的生存与死亡人数')
ax.legend(title='生存情况')
保存图(ROOT / '01_性别生存分组柱状图.png')
# 2. 仅用已知年龄；直方图的纵轴为人数，不解释为条件生存率。
fig, ax = plt.subplots(figsize=(9, 5))
for value, color, label in [(0, '#c77676', '未生存'), (1, '#4d99b2', '生存')]:
    ax.hist(df.loc[df.Survived.eq(value), 'Age'].dropna(), bins=np.arange(0, 86, 5),
            alpha=.58, color=color, label=label)
ax.set(xlabel='年龄（岁）', ylabel='人数', title=f'C2：已知年龄的分布（n={df.Age.notna().sum()}）')
ax.legend(title='生存情况')
保存图(ROOT / '02_年龄分布图.png')
# 3. 年龄组生存率；不将缺失年龄填成均值，另表报告缺失组。
fig, ax = plt.subplots(figsize=(10, 5))
ax.bar(age.index.astype(str), age['生存率%'], color='#739e70')
for i, (_, row) in enumerate(age.iterrows()):
    ax.text(i, row['生存率%']+2, f'{row["生存率%"]:.1f}%\nn={int(row["样本数"])}', ha='center')
ax.set(ylim=(0, 100), xlabel='年龄段（左闭右开，缺失者另列）', ylabel='生存率（%）', title='C3：不同年龄段的样本生存率')
保存图(ROOT / '03_年龄段生存率.png')
# 4. 舱位生存率。
fig, ax = plt.subplots(figsize=(8, 5))
ax.bar(['一等舱', '二等舱', '三等舱'], pclass['生存率%'], color='#669fbd')
for i, (_, row) in enumerate(pclass.iterrows()):
    ax.text(i, row['生存率%']+2, f'{row["生存率%"]:.1f}%\nn={int(row["样本数"])}', ha='center')
ax.set(ylim=(0, 100), xlabel='舱位等级', ylabel='生存率（%）', title='C4：不同舱位等级的生存率')
保存图(ROOT / '04_舱位生存率.png')
# 5. 重点缺失矩阵，按舱位排序，并标记舱位边界。
fig, ax = plt.subplots(figsize=(7, 6))
ordered = df.sort_values('Pclass', kind='stable')
sns.heatmap(ordered[['Age', 'Cabin']].isna().astype(int), cmap=['#e6eef3', '#ce5555'],
            vmin=0, vmax=1, yticklabels=False, cbar_kws={'ticks': [0, 1], 'label': '0=有记录；1=缺失'}, ax=ax)
for boundary in df.Pclass.value_counts().sort_index().cumsum().iloc[:-1]: ax.axhline(boundary, color='black', linewidth=1)
ax.set(xlabel='字段：年龄、船舱号', ylabel='乘客（依次为一、二、三等舱；黑线分隔）', title='C5：年龄与船舱号缺失模式')
保存图(ROOT / '05_Age与Cabin缺失模式.png')
eda['年龄缺失'] = eda.Age.isna()
eda['船舱号缺失'] = eda.Cabin.isna()
missing_tables = {}
for col in ['Pclass', 'Sex', 'Survived']:
    table = eda.groupby(col)[['年龄缺失', '船舱号缺失']].mean()*100
    table.insert(0, '样本数', eda.groupby(col).size())
    保存表(table, ROOT / f'缺失率按{col}分组.csv')
    missing_tables[col] = table
保存表(pd.crosstab(eda['年龄缺失'], eda['船舱号缺失'], margins=True), ROOT / '年龄与船舱号联合缺失.csv')
# 6. 缺失与舱位及生存状态的关联。
fig, axes = plt.subplots(1, 2, figsize=(11, 5))
for ax, key, title, xlabel in [(axes[0], 'Pclass', '各舱位缺失率', '舱位等级'),
                                (axes[1], 'Survived', '按生存状态的缺失率', '0=未生存，1=生存')]:
    missing_tables[key][['年龄缺失', '船舱号缺失']].plot.bar(ax=ax, rot=0, color=['#70a9c8', '#d18383'])
    ax.set(ylim=(0, 100), title=title, xlabel=xlabel, ylabel='组内缺失率（%）')
    ax.legend(fontsize=8)
保存图(ROOT / '06_缺失率与舱位生存状态.png')
# 7. 原始尺度和 log1p 尺度并排展示；高票价仅标记，不直接删除。
eda['LogFare'] = np.log1p(eda.Fare)
fig, axes = plt.subplots(1, 2, figsize=(11, 5))
for ax, col, title, ylabel in [(axes[0], 'Fare', '原始票价分布', '票价 Fare'),
                             (axes[1], 'LogFare', '对数变换后的票价分布', 'ln(1+Fare)')]:
    sns.boxplot(data=eda, x='Pclass', y=col, order=[1, 2, 3], ax=ax, color='#8fb7c9')
    ax.set(title=title, xlabel='舱位等级', ylabel=ylabel)
保存图(ROOT / '07_票价箱线图.png')
fare_rows = []
fare_flags = pd.Series(False, index=df.index)
for group, sub in df.groupby('Pclass'):
    q1, q3 = sub.Fare.quantile([.25, .75])
    lo, hi = q1-1.5*(q3-q1), q3+1.5*(q3-q1)
    flag = (sub.Fare < lo) | (sub.Fare > hi)
    fare_flags.loc[sub.index] = flag
    fare_rows.append({'舱位': int(group), '下界': lo, '上界': hi, '异常候选数': int(flag.sum()),
                     '零票价人数': int(sub.Fare.eq(0).sum())})
保存表(df.groupby('Pclass').Fare.describe(), ROOT / '各舱位票价描述统计.csv')
保存表(pd.DataFrame(fare_rows), ROOT / '票价IQR候选统计.csv', index=False)
保存表(df.loc[fare_flags], ROOT / '票价异常候选记录.csv')
保存表(eda, ROOT / '分析用数据.csv', index=False)
summary = {'样本数': len(df), '生存人数': int(df.Survived.sum()), '死亡人数': int((1-df.Survived).sum()),
 '总体生存率': float(df.Survived.mean()), '重复记录数': int(df.duplicated().sum()),
 '年龄缺失数': int(df.Age.isna().sum()), '船舱号缺失数': int(df.Cabin.isna().sum()),
 '年龄缺失组生存率': float(unknown.Survived.mean()), '性别生存率': sex['生存率'].to_dict(),
 '舱位生存率': pclass['生存率'].to_dict(), '已知年龄样本数': int(df.Age.notna().sum()),
 '票价异常候选数': int(fare_flags.sum()), '零票价数': int(df.Fare.eq(0).sum())}
assert int(age['样本数'].sum()) + len(unknown) == len(df)
assert sex['生存人数'].sum() == df.Survived.sum()
assert (joint.xs('female', level='Sex')['生存率'] > joint.xs('male', level='Sex')['生存率']).all()
assert len(list(ROOT.glob('*.png'))) == 7
保存结果(summary, ROOT / '分析摘要.json')
report = (
 f'本分析使用891名乘客、12个字段的经典训练集，{summary["生存人数"]}人生存、{summary["死亡人数"]}人死亡，总体生存率为{df.Survived.mean():.2%}。未进行模型训练。\n\n'
 f'女性生存率{sex.loc["female", "生存率"]:.2%}，男性为{sex.loc["male", "生存率"]:.2%}；一、二、三等舱分别为'
 f'{pclass.loc[1,"生存率"]:.2%}、{pclass.loc[2,"生存率"]:.2%}、{pclass.loc[3,"生存率"]:.2%}。性别与舱位交叉表显示，各舱位女性生存率均高于同舱男性。上述差异是样本关联，不能直接解释为单一因素的因果效果。\n\n'
 f'年龄已知{df.Age.notna().sum()}人、缺失{df.Age.isna().sum()}人；仅已知年龄者参与年龄图和分组，缺失者单列，生存率为{unknown.Survived.mean():.2%}。'
 f'0—11岁组{int(age.iloc[0]["样本数"])}人、生存率{age.iloc[0]["生存率"]:.2%}；60岁及以上组{int(age.iloc[-1]["样本数"])}人、生存率{age.iloc[-1]["生存率"]:.2%}。年龄组生存率并非严格单调；分组边界和小样本会影响比较。直方图展示人数，不能仅凭柱高推断条件生存率。\n\n'
 f'Cabin缺失{df.Cabin.isna().sum()}条（{df.Cabin.isna().mean():.2%}）。一等舱船舱号缺失率为{missing_tables["Pclass"].loc[1,"船舱号缺失"]:.2f}%，三等舱为{missing_tables["Pclass"].loc[3,"船舱号缺失"]:.2f}%；'
 f'未生存组为{missing_tables["Survived"].loc[0,"船舱号缺失"]:.2f}%，生存组为{missing_tables["Survived"].loc[1,"船舱号缺失"]:.2f}%。缺失与已观察到的舱位和生存状态存在关联，不宜直接假设完全随机缺失；仅凭EDA不能判定完整的缺失机制。\n\n'
 f'分舱位IQR标记{fare_flags.sum()}条票价候选，另有{df.Fare.eq(0).sum()}条零票价。高票价可能与舱位、多人共票等有关，零票价也需回查背景，均保留。原始与log1p箱线图分别展示金额和中心区域；变换尺度的IQR候选不必与原始尺度一致。\n\n'
 '结论限于该训练样本。年龄缺失和完整案例筛选可能引入偏差；小年龄组比例更不稳定。该训练集不是全部乘客普查，舱位、性别、年龄与救援安排相互关联，不应将描述性差异推广为总体因果结论。')
(ROOT / '探索性分析报告.txt').write_text(report, encoding='utf-8')
print(summary)
