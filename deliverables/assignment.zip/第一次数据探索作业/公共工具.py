"""少量共用的路径、中文字体和结果保存函数。"""
from pathlib import Path
import os
import json
import io

项目目录 = Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR', str(项目目录 / '.cache' / 'matplotlib'))
import matplotlib
matplotlib.use('Agg')  # 无显示器的云环境也能生成图片
import matplotlib.pyplot as plt
from matplotlib import font_manager
import seaborn as sns

def 设置绘图():
    sns.set_theme(style='whitegrid')
    font = 项目目录 / '资源/NotoSansCJKsc-Regular.otf'
    font_manager.fontManager.addfont(str(font))
    plt.rcParams['font.family'] = font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['font.size'] = 10

def 保存图(path):
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches='tight')
    plt.close()

def 保存表(df, path, index=True):
    df.to_csv(path, index=index, encoding='utf-8-sig')

def 保存结果(result, path):
    Path(path).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')

def 保存概况(df, path):
    buffer = io.StringIO()
    df.info(buf=buffer)
    text = f'数据形状：{df.shape}\n字段名称：{df.columns.tolist()}\n\n{buffer.getvalue()}\n前五行：\n{df.head().to_string()}\n'
    Path(path).write_text(text, encoding='utf-8')
    print(text)
