# 第一次数据探索——完整课程作业

项目包含完整A、B、C、D四题，全部统计结果来自实际运行。优先阅读 `第一次数据探索_完整作业报告.docx`；可直接提交Word，或按课程要求提交整个项目压缩包。报告没有虚构姓名、学号或班级。

## 运行方法

建议Python 3.12（本次实际使用3.12.14）。所有数据和中文字体已经保存，分析无需网络或Kaggle账号。在项目目录执行：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python 一键运行.py
```

Windows激活命令为 `.venv\Scripts\activate`。也可直接依次运行：

```bash
python A_异常值检测/A_异常值检测.py
python B_真实数据EDA/B_数据探索.py
python C_Titanic数据探索/C_Titanic数据探索.py
python 生成Word报告.py
python 验证成果.py
```

当前云环境已安装依赖，直接使用：

```bash
/workspace/tizzy001-env/.venv/bin/python /workspace/第一次数据探索作业/一键运行.py
```

脚本按自身位置找到输入，因此从其他工作目录启动也有效。重复运行会刷新生成结果、图片、日志和报告，但不会覆盖B/C原始CSV。修改分析代码后，应重跑全流程以确保Word与结果一致。验证脚本核验当前交付版本的数据规模及已知结果，若有意更换数据或实验设计，应同步调整验证规则。

## 各题内容与索引口径

- A：固定种子2026，300个均值100、标准差15的正常值，加5个明显异常；随机打乱。`当前行索引`从0开始；`原始行索引`为打乱前位置，真实异常原始索引300—304。IQR检出9条，其中真正例5、假正例4、漏检0；1张图。
- B：ggplot2/seaborn真实钻石价格数据，53,940行、10个字段。含基本信息、缺失处理、重复候选、7字段IQR、描述统计、相关矩阵、切工记录数帕累托图和约200字结论；4张图。零尺寸按字段置缺失，其他有效属性保留；相同属性没有商品唯一ID，重复候选不直接删除。
- C：Kaggle Titanic经典训练集教学镜像，891行、12字段，含Survived。保存人数、死亡人数、生存率、性别与舱位交叉表、年龄分组及缺失组、全部字段缺失率、分组缺失模式和票价IQR；7张图，不建立预测模型。
- D：12种理论上的电商数据质量问题，列出异常现象、影响、检测方法、处理方案和优先级；没有编造交易数据。

共12张统计图片，Word全部插入。CSV为UTF-8 BOM编码；完整精度以CSV和JSON为准，Word数值适当四舍五入。`统计结果.csv`是Titanic总体/性别/舱位/年龄的统一汇总，其他详细表按名称单独保存。

## 数据来源与限制

- B：<https://ggplot2.tidyverse.org/reference/diamonds.html>；下载镜像：<https://raw.githubusercontent.com/mwaskom/seaborn-data/master/diamonds.csv>。原计划使用UCI Online Retail，但官方下载被当前网络代理返回403，因此选择可追溯的钻石商品价格数据。这是价格与属性横截面，不是成交订单，不能把价格加总称为销售额，也不能把记录占比称为市场份额。
- C：官方页面 <https://www.kaggle.com/competitions/titanic/data>；教学镜像 <https://raw.githubusercontent.com/ageron/handson-ml2/master/datasets/titanic/train.csv>。复用环境已下载文件，核验结构、标签、样本量和SHA-256；未声称与需要登录的官方文件逐字节比对。
- 字体：<https://github.com/notofonts/noto-cjk>，Noto Sans CJK SC，SIL Open Font License 1.1；字体与许可证均随附。
- 获取日期、原始文件位置及SHA-256见 `数据来源.json`；摘要用于确认文件版本，不是数据真实性的独立证明。

图表中文已嵌入PNG像素。Word使用Noto Sans CJK SC字体；若本机缺少该字体，可安装 `资源/NotoSansCJKsc-Regular.otf`，或在Word中选择其他中文字体，避免字体替代影响排版。

## 验收与文件说明

`运行记录/`保存程序实际输出；`验证结果.json`记录统计一致性、图片解码、DOCX结构与内容检查。Word已经通过python-docx重新打开，验证12张嵌入图片、表格和页码字段；另外已使用可用的soffice无界面转换器生成25页PDF，检查全部页面非空、四题内容完整，并抽查渲染页面。未使用桌面Microsoft Word逐页验证。

报告各节包括题目要求、方法、关键代码、实际表格与图表解释；完整代码位于A/B/C目录，报告生成程序与验证程序同样提供。`公共工具.py`仅集中管理中文绘图、保存表格和路径，不包含隐藏的分析逻辑。

`.cache`和`__pycache__`仅为可再生运行缓存，不进入提交压缩包；无需随项目提交虚拟环境。最终ZIP位于项目目录旁边。

如重新运行或修改成果，先完成验证，再执行 `python 打包作业.py` 更新ZIP及 `文件校验清单.json`。打包程序逐文件核验压缩包内的SHA-256，确保与当前成果一致。

## 直接阅读报告

聊天文件面板不支持预览ZIP，这不表示压缩包损坏。请先打开同目录中的 `第一次数据探索_完整作业报告.pdf`，共25页；需要编辑时使用DOCX。ZIP包含代码、原始数据、图表和报告，下载后使用系统解压工具展开。
