"""A：随机打乱后的混合数据，IQR 检测与已知真值比较。"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 公共工具 import 设置绘图, 保存图, 保存表, 保存结果
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
设置绘图()
rng = np.random.default_rng(2026)
# 本题约定 N(100,15) 的第二个参数为标准差，而不是方差。
normal = rng.normal(loc=100, scale=15, size=300)
injected = np.concatenate([rng.uniform(10, 30, 2), rng.uniform(175, 205, 3)])
data = pd.DataFrame({'原始行索引': np.arange(305),
                     '数值': np.concatenate([normal, injected]),
                     '真实异常': [False] * 300 + [True] * 5})
# 保存打乱前原始索引，并另设从零开始的当前行索引，避免两个口径混淆。
data = data.iloc[rng.permutation(len(data))].reset_index(drop=True)
data.index.name = '当前行索引'
q1, q3 = data['数值'].quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
data['IQR判为异常'] = (data['数值'] < lower) | (data['数值'] > upper)
data['检测分类'] = np.select(
    [data['真实异常'] & data['IQR判为异常'], ~data['真实异常'] & data['IQR判为异常'],
     data['真实异常'] & ~data['IQR判为异常']], ['真正例', '假正例', '漏检'], default='真负例')
detected = data.loc[data['IQR判为异常']]
truth = data.loc[data['真实异常']]
tp = int((data['检测分类'] == '真正例').sum())
fp = int((data['检测分类'] == '假正例').sum())
fn = int((data['检测分类'] == '漏检').sum())
tn = int((data['检测分类'] == '真负例').sum())
保存表(data, ROOT / '模拟数据.csv')
保存表(detected, ROOT / '异常值检测结果.csv')
保存表(truth, ROOT / '真实注入异常值.csv')
保存表(pd.DataFrame([[tp, fn], [fp, tn]], index=['真实异常', '真实正常'],
                    columns=['判为异常', '判为正常']), ROOT / '混淆矩阵.csv')
plt.figure(figsize=(10, 4))
sns.boxplot(x=data['数值'], whis=1.5, color='#85b9d4')
plt.scatter(truth['数值'], np.zeros(5), c='#c72d31', marker='x', s=70, label='5个人工注入异常', zorder=5)
plt.axvline(lower, linestyle='--', color='#ba7300', label='IQR下界')
plt.axvline(upper, linestyle='--', color='#2d7c44', label='IQR上界')
plt.xlabel('数值（正态部分：均值100，标准差15）')
plt.ylabel('混合样本')
plt.title('A：打乱后的305个观测及IQR异常筛查')
plt.legend(loc='upper center', fontsize=8)
保存图(ROOT / '箱线图.png')
summary = {'随机种子': 2026, '样本量': len(data), 'Q1': float(q1), 'Q3': float(q3),
           'IQR': float(iqr), '下界': float(lower), '上界': float(upper),
           '检测当前行索引': detected.index.tolist(), '真实异常当前行索引': truth.index.tolist(),
           '真实异常原始行索引': truth['原始行索引'].tolist(),
           '真正例': tp, '假正例': fp, '漏检': fn, '真负例': tn,
           '全部检出': fn == 0, '精确率': tp / (tp + fp), '召回率': tp / (tp + fn)}
assert len(data) == 305 and data['真实异常'].sum() == 5
assert tp + fn == 5 and fp + tn == 300
assert set(truth.index) != set(range(300, 305))
assert tp == 5 and fn == 0
保存结果(summary, ROOT / '分析摘要.json')
print(detected.to_string())
print(summary)
