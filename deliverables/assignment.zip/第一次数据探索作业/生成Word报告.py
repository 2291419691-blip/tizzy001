"""读取实际运行产物，生成带图表、页码和中文格式的完整Word报告。"""
from pathlib import Path
import json
import math
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.section import WD_SECTION_START, WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
A = ROOT / 'A_异常值检测'
B = ROOT / 'B_真实数据EDA'
C = ROOT / 'C_Titanic数据探索'
sa = json.loads((A / '分析摘要.json').read_text())
sb = json.loads((B / '分析摘要.json').read_text())
sc = json.loads((C / '分析摘要.json').read_text())
sources = json.loads((ROOT / '数据来源.json').read_text())
doc = Document()
section = doc.sections[0]
section.page_width, section.page_height = Cm(21), Cm(29.7)
section.top_margin = section.bottom_margin = Cm(2)
section.left_margin = section.right_margin = Cm(2)
for name in ['Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2', 'Heading 3', 'Caption']:
    style = doc.styles[name]
    style.font.name = 'Noto Sans CJK SC'
    style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
doc.styles['Normal'].font.size = Pt(10.5)
doc.styles['Normal'].paragraph_format.line_spacing = 1.25
doc.styles['Normal'].paragraph_format.space_after = Pt(5)
for name, size in [('Heading 1', 17), ('Heading 2', 13), ('Heading 3', 11)]:
    doc.styles[name].font.size = Pt(size)
    doc.styles[name].font.color.rgb = RGBColor.from_string('205779')
doc.styles['Caption'].font.size = Pt(9)
footer = section.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('第 ')
field = OxmlElement('w:fldSimple')
field.set(qn('w:instr'), 'PAGE')
footer._p.append(field)
footer.add_run(' 页')
header = section.header.paragraphs[0]
header.text = '第一次数据探索 · Python 探索性数据分析'
header.style = doc.styles['Caption']
doc.core_properties.title = '第一次数据探索——Python探索性数据分析课后作业'
doc.core_properties.subject = '异常值检测、真实商品数据EDA、Titanic分析与电商数据质量'
doc.core_properties.author = '课程作业'
figure_count = 0
table_count = 0

def p(text):
    doc.add_paragraph(str(text))

def h(text, level=2):
    doc.add_heading(text, level=level)

def fmt(value):
    if pd.isna(value): return '—'
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else f'{value:.3f}'
    return str(value)

def table(frame, title, index=True, size=8):
    global table_count
    table_count += 1
    doc.add_paragraph(f'表{table_count}  {title}', style='Caption')
    frame = frame.reset_index() if index else frame.copy()
    t = doc.add_table(rows=1, cols=len(frame.columns))
    t.style = 'Table Grid'
    for cell, name in zip(t.rows[0].cells, frame.columns): cell.text = str(name)
    repeat = OxmlElement('w:tblHeader')
    t.rows[0]._tr.get_or_add_trPr().append(repeat)
    for values in frame.itertuples(index=False, name=None):
        for cell, value in zip(t.add_row().cells, values): cell.text = fmt(value)
    for row in t.rows:
        no_split = OxmlElement('w:cantSplit')
        row._tr.get_or_add_trPr().append(no_split)
        for cell in row.cells:
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(2)
                para.paragraph_format.line_spacing = 1.0
                for run in para.runs: run.font.size = Pt(size)
    for cell in t.rows[0].cells:
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), 'DFEBF2')
        cell._tc.get_or_add_tcPr().append(shading)
        for run in cell.paragraphs[0].runs: run.bold = True

def csv_table(path, title, cols=None, size=8):
    frame = pd.read_csv(path)
    frame = frame.rename(columns={frame.columns[0]: '字段/分组'}) if str(frame.columns[0]).startswith('Unnamed') else frame
    table(frame if cols is None else frame[cols], title, index=False, size=size)

def figure(path, title, explanation):
    global figure_count
    figure_count += 1
    para = doc.add_paragraph()
    para.paragraph_format.keep_with_next = True
    para.add_run().add_picture(str(path), width=Inches(6.3))
    caption = doc.add_paragraph(f'图{figure_count}  {title}', style='Caption')
    caption.paragraph_format.keep_with_next = True
    p(explanation)

def code(path, first, last):
    lines = path.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if first in line)
    end = next(i for i in range(start, len(lines)) if last in lines[i])
    para = doc.add_paragraph()
    para.paragraph_format.line_spacing = 1.0
    for line in lines[start:end+1]:
        run = para.add_run(line + '\n')
        run.font.name = 'Consolas'
        run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Noto Sans CJK SC')
        run.font.size = Pt(8)

def overview(path):
    df = pd.read_csv(path)
    table(pd.DataFrame({'字段': df.columns, '类型': df.dtypes.astype(str).values,
                        '非空数': df.notna().sum().values}), '字段类型与非空数量', index=False)
    first = df.head().T
    first.columns = ['第1行', '第2行', '第3行', '第4行', '第5行']
    table(first, '前五行（转置显示，保留原始字段值）', size=7)

title = doc.add_paragraph(style='Title')
title.add_run('第一次数据探索——Python探索性数据分析课后作业')
p('A 异常值检测｜B 真实钻石价格数据EDA｜C Titanic探索｜D 电商数据质量')
p(f'数据获取与运行日期：{sources["获取日期"]}。全部结果来自随附Python程序的实际执行；本报告未训练预测模型。')
h('作业范围与运行环境')
p('使用Python 3.12，主要依赖NumPy、Pandas、Matplotlib与Seaborn，Word由python-docx生成。数据、中文字体、代码、统计表与图表均随项目保存，运行不依赖联网。源代码采用固定随机种子和明确工作路径，CSV采用UTF-8 BOM编码以便Excel打开。')
p('A题1张图，B题4张图，C题7张图，共12张。报告表格保留适当小数位；完整精度以CSV和JSON文件为准。页面中的“—”表示缺失或不适用，不能解释为0。')
p('本报告依次包含题目要求、方法、关键代码、运行结果与解释；完整Python程序另附，便于检查与复现。')

doc.add_page_break()
h('A  基础题：异常值检测', 1)
h('A1 题目要求与方法')
p('生成300个正态值与5个人工随机异常，随机打乱后用箱线图和IQR规则筛查，返回行索引，并用已知真值评估检出情况。约定N(100,15)中的15为标准差σ，方差为225；部分教材以第二参数表示方差，若按该记法标准差应为√15，本实验不采用该口径。')
p('随机数生成器使用default_rng(2026)。正常值不截断、不换种子；两个低异常来自[10,30)，三个高异常来自[175,205)。先记录原始行索引0—304，再用同一生成器随机排列，重建当前行索引。真实异常的原始索引为300—304，但当前位置已分散。')
p('Q1和Q3采用Pandas默认线性分位数；IQR=Q3−Q1。严格小于Q1−1.5IQR或大于Q3+1.5IQR者为异常候选。箱线图须线延伸到界限内最远的实际观测，并非直接延伸到理论边界。检测过程仅用数值，真值标签只参与评估。')
h('A2 关键代码')
code(A/'A_异常值检测.py', 'rng = ', "data['IQR判为异常'] =")
h('A3 实际结果')
table(pd.DataFrame({'统计量':['Q1','Q3','IQR','下界','上界'], '数值':[sa[k] for k in ['Q1','Q3','IQR','下界','上界']]}), 'IQR阈值', index=False)
p('检测到的当前行索引（从0开始）：' + '、'.join(map(str, sa['检测当前行索引'])) + '。')
p('真实注入异常的当前行索引：' + '、'.join(map(str, sa['真实异常当前行索引'])) + '。下表中的原始行索引用于追溯打乱前的位置。')
csv_table(A/'异常值检测结果.csv', '全部异常候选及真值对照')
csv_table(A/'混淆矩阵.csv', '检测混淆矩阵')
p(f'真正例{sa["真正例"]}、假正例{sa["假正例"]}、漏检{sa["漏检"]}、真负例{sa["真负例"]}。召回率{sa["召回率"]:.1%}，精确率{sa["精确率"]:.1%}：全部5个人工异常均检出，但并非只标记了5条。')
figure(A/'箱线图.png', '混合数据箱线图', '红色叉号为已知的5个人工异常，虚线是理论IQR边界。4个正常生成的尾部观测也超出界限，因此被计为相对于人工标签的假正例；它们不是自动认定的数据错误。')
h('A4 分析结论与局限')
p('IQR利用中间50%数据构造较稳健的筛查范围。自然尾部、偏态或混合总体可能导致误检；异常落在界限内、样本量小或异常群体扩大IQR时可能漏检。本次异常刻意放在远离中心的区域，因此成功检出不能保证其他场景也达到100%召回。')

doc.add_page_break()
h('B  数据分析题：真实钻石价格数据EDA', 1)
h('B1 题目要求、数据来源与基本信息')
p('完成形状与基本信息、缺失处理、异常检测、描述统计、Pearson热力图、帕累托图及约200字结论七项要求。选择ggplot2经典diamonds真实商品价格数据，由seaborn-data公开镜像提供。UCI Online Retail官方下载在当前环境被代理返回403，因此使用可访问且可追溯的商品数据。')
p('数据名称：diamonds；原始形状为53,940行、10列。它是钻石价格和属性的横截面，没有成交数量、日期或订单编号，不能把价格之和解释成销售收入。')
p('原项目：'+sources['B']['原项目'])
p('CSV获取地址：'+sources['B']['获取地址'])
p('字段含义：carat为重量（克拉），cut为切工，color为颜色等级（D至J），clarity为净度；depth为总深度百分比，table为台面宽度占最大宽度的百分比；price为美元价格，x、y、z分别为长、宽、深（毫米）。')
overview(B/'原始数据.csv')
h('B2 缺失值、重复值与处理')
p(f'原始表各字段无缺失，但有{sb["零尺寸记录数"]}条记录含不可能的零物理尺寸：x有8个、y有7个、z有20个，字段间存在重叠，不能相加当作记录数。零尺寸改记缺失；保留整条记录和其他有效属性，不使用均值填补。描述统计逐列使用有效值，相关分析统一采用{sb["完整案例数"]:,}个完整案例。')
p(f'raw.duplicated()识别出{sb["完全重复候选数"]}条与此前记录完全相同的候选，即不计每组首次出现的额外记录数。由于没有唯一钻石ID，相同属性也可能代表不同商品，不直接删除。清洗表额外标记所有属于重复组的记录，因此该标记总数与“额外重复行数”口径不同。')
csv_table(B/'缺失值统计.csv', '处理前后缺失情况')
h('B3 IQR异常检测与描述性统计')
p('对7个数值字段分别进行1.5IQR筛查并保存行级候选。高价和大克拉可能是真实商品；异常尺寸需要回查测量单位与来源。除物理上无效的非正尺寸置缺失外，不依据IQR自动删除或截尾。缺失值本身不被IQR判为异常，而由缺失统计单独记录。')
csv_table(B/'IQR异常统计.csv', '各字段IQR异常候选', size=7)
p(f'至少一个字段超出IQR界限的记录共有{sb["任一IQR候选数"]:,}条，其中价格候选{sb["价格IQR候选数"]:,}条。不同字段候选可能重叠，不能直接相加。')
desc = pd.read_csv(B/'描述性统计.csv', index_col=0)
table(desc[['count','mean','median','std','min','max']], '描述统计：有效数、均值、中位数、样本标准差及极值', size=7)
table(desc[['25%','50%','75%','skew']], '四分位数与偏度')
h('B4 关键代码')
code(B/'B_数据探索.py', 'for col in numeric:', "保存表(pd.DataFrame(iqr_rows)")
code(B/'B_数据探索.py', 'counts = ', "保存表(pareto,")
h('B5 相关分析与图表')
figure(B/'相关系数热力图.png', '钻石属性Pearson相关热力图', f'统一使用{sb["完整案例数"]:,}个完整案例，颜色固定在−1至1。重量与价格相关系数为{sb["重量价格相关"]:.3f}。类别变量未任意编码求Pearson相关；尺寸共线性、商品品质和极端值均会影响关系，不能从相关推出因果。')
csv_table(B/'切工帕累托统计.csv', '切工类别记录数与累计占比')
figure(B/'帕累托图.png', '切工类别记录数帕累托图', '柱形按记录数降序，折线为累计记录数除以53,940，末点为100%；横线为80%参考。前3类约占87.9%，不是预设的二八定律。记录占比不等于销量、收入或市场份额。')
figure(B/'价格分布与箱线图.png', '价格分布及不同切工的箱线图', f'价格均值{sb["价格均值"]:.2f}美元高于中位数{sb["价格中位数"]:.0f}美元，呈右偏。不同切工的价格同时受重量、颜色和净度构成影响，不能只凭箱线图断言切工的独立价格效应。')
figure(B/'重量与价格关系.png', '重量—价格密度图', '六边形网格汇总密集观测，色标使用对数以缓解重叠。总体随重量上升的价格趋势明显，但同重量仍有较大价格差异，单个相关系数不能表达全部结构。')
h('B6 约200字分析结论')
p(sb['结论'])
p(f'结论共{sb["结论字符数"]}个字符（含数字与标点）。局限：样本无完整抽样框和订单粒度，价格随市场时期变化；零尺寸、可疑极端尺寸、重复候选的未核实部分，以及完整案例选择均可能影响结果。')

doc.add_page_break()
h('C  挑战题：Kaggle Titanic探索', 1)
h('C1 题目要求、数据来源与基本信息')
p('使用带Survived标签的经典训练集，研究性别、年龄、舱位与生存率、年龄及船舱号缺失模式，以及分舱位票价分布；仅做EDA，不训练模型、不计算预测准确率。')
p('官方入口：'+sources['C']['原项目'])
p('可信公开教学镜像：'+sources['C']['获取地址'])
p('复用环境中已保存的镜像CSV，核验891行、12列、PassengerId唯一、Survived为0或1、Pclass为1至3；未声称与需登录的Kaggle原始下载进行了逐字节校验。Pclass为舱位等级，Cabin为具体船舱号；二者不可混为一谈。SibSp为同船兄弟姐妹/配偶数，Parch为父母/子女数。')
overview(C/'train.csv')
cdesc = pd.read_csv(C/'描述性统计.csv', index_col=0)
table(cdesc.loc[['Age','Fare','SibSp','Parch'], ['count','mean','std','min','25%','50%','75%','max']], '年龄、票价与亲属数量描述统计', size=7)
p('PassengerId是身份标识，不解释其均值；Pclass和Survived按分类/二元标签解释。完整数值及类别描述统计见CSV。完全重复记录数为0。')
h('C2 缺失处理与关键代码')
csv_table(C/'所有字段缺失统计.csv', '全部字段缺失数量和比例')
p('Age缺失177条，Cabin缺失687条，Embarked缺失2条。年龄图与分组仅用714个已知年龄，缺失组另列；不以均值年龄填补，不猜测船舱号。登船港不参与本次重点分析，保留缺失。分组比例的分母均为本组人数。')
code(C/'C_Titanic数据探索.py', 'def 生存汇总', "return result[['样本数'")
code(C/'C_Titanic数据探索.py', "labels = ['0—11岁'", "age = 生存汇总")
h('C3 总体、性别与舱位生存情况')
csv_table(C/'总体生存统计.csv', '总体生存情况')
csv_table(C/'性别生存统计.csv', '不同性别的生存人数、死亡人数和比率')
figure(C/'01_性别生存分组柱状图.png', '不同性别的生存与死亡人数', '女性生存率74.20%，男性18.89%。图中柱高是人数，性别样本量不同，比较生存倾向应同时查看表中的组内比例。')
csv_table(C/'舱位生存统计.csv', '不同舱位的样本量与生存率')
figure(C/'04_舱位生存率.png', '不同舱位等级的生存率', '一等舱62.96%、二等舱47.28%、三等舱24.24%。三等舱人数最多，而生存率最低；这反映样本关联，不等同于只由票价或舱位单独造成的因果效应。')
csv_table(C/'性别与舱位交叉生存统计.csv', '性别×舱位的分层对照')
p('各舱位中女性的生存率均高于男性，分层对照支持差异并非只来自总体舱位构成；仍可能存在年龄、救援顺序等其他混杂。')
h('C4 年龄分布与年龄组生存率')
figure(C/'02_年龄分布图.png', '按生存情况展示年龄分布', '仅展示已知年龄者，5岁一个区间，两组直方图透明叠加。高度是人数而非概率；年龄缺失者未被塞入任何年龄段。')
csv_table(C/'年龄组生存统计.csv', '已知年龄分组（区间左闭右开）')
csv_table(C/'年龄缺失生存统计.csv', '年龄缺失者单独汇总')
figure(C/'03_年龄段生存率.png', '不同年龄组的生存率', '0—11岁组具有较高生存率，但各年龄段并非严格单调下降。每根柱标出分母，小年龄组比率波动更大；分组边界改变也会改变结果，不应将其当作每增加一岁的独立效应。')
h('C5 Age与Cabin缺失分布')
figure(C/'05_Age与Cabin缺失模式.png', '年龄与船舱号缺失矩阵', '乘客按舱位排序，黑线分隔三组。红色表示缺失而非数值较大；船舱号缺失在三等舱更集中。')
csv_table(C/'缺失率按Pclass分组.csv', '按舱位的缺失率（%）')
csv_table(C/'缺失率按Survived分组.csv', '按生存状态的缺失率（%）')
csv_table(C/'缺失率按Sex分组.csv', '按性别的缺失率（%）')
figure(C/'06_缺失率与舱位生存状态.png', '缺失率与舱位、生存状态关联', '图表显示Cabin缺失与舱位和生存状态有关。由于舱位与生存状态也相关，不能把每个差异独立解释；仅凭这些表无法证明MAR或MNAR等完整缺失机制。')
h('C6 分舱位票价箱线图')
csv_table(C/'各舱位票价描述统计.csv', '分舱位票价描述统计', size=7)
csv_table(C/'票价IQR候选统计.csv', '分舱位原始票价IQR候选与零票价')
figure(C/'07_票价箱线图.png', '不同舱位的票价箱线图', '票价右偏，高价可能代表多人共同购票或不同舱位服务，不能直接当成错误。本次按舱位在原始尺度上标记79条候选，15条零票价另列。log1p允许保留零值并观察中心分布；右图的箱线边界在变换尺度计算，不能与左图候选逐点等同。')
h('C7 从数据中可以看出的规律')
for paragraph in (C/'探索性分析报告.txt').read_text().split('\n\n'): p(paragraph)

# D题的五列表格采用横向页面，减少长中文被挤成窄列。
land = doc.add_section(WD_SECTION_START.NEW_PAGE)
land.orientation = WD_ORIENT.LANDSCAPE
land.page_width, land.page_height = Cm(29.7), Cm(21)
land.left_margin = land.right_margin = Cm(1.6)
h('D  思维题：你是数据侦探', 1)
h('D1 题目、方法与优先级')
p('仅给出用户ID、下单时间、商品类别、金额、是否退货五个字段，没有提供实际交易数据。以下12项均为潜在问题及处理建议，不声称发现了真实问题。本题无需编造数据或运行统计程序。P0先确认关键结构与口径，P1核查数值和跨字段逻辑，P2检查观察窗口与覆盖范围。')
md = (ROOT/'D_电商数据质量分析/D_思考题答案.md').read_text()
rows = [line for line in md.splitlines() if line.startswith('|')]
headers = [s.strip() for s in rows[0].strip('|').split('|')]
items = [[s.strip() for s in line.strip('|').split('|')] for line in rows[2:]]
table(pd.DataFrame(items, columns=headers), '电商潜在数据质量问题、影响、检测与处理', index=False, size=9)
h('D2 推荐检查顺序和结论')
for line in md.split('## 建议检查顺序')[1].split('## 总结')[0].strip().splitlines():
    if line.strip(): p(line)
p(md.split('## 总结')[1].strip())

portrait = doc.add_section(WD_SECTION_START.NEW_PAGE)
portrait.orientation = WD_ORIENT.PORTRAIT
portrait.page_width, portrait.page_height = Cm(21), Cm(29.7)
portrait.left_margin = portrait.right_margin = Cm(2)
h('附录：来源、复现与验收', 1)
h('数据与字体来源')
for key in ['B','C','字体']:
    item = sources[key]
    p(f'{key}：{item["名称"]}；地址：{item["获取地址"]}')
    p(f'文件：{item["文件"]}；SHA-256：{item["sha256"]}')
p('文件摘要用于确认当前文件版本和复现一致性，并非数据真实性的独立证明。字体许可随资源目录提供。Word引用Noto Sans CJK SC字体；若本机未安装可使用随附字体，图表中文已作为像素写入PNG。')
h('复现步骤与文件对应')
p('在项目目录安装requirements.txt后，依次运行A_异常值检测/A_异常值检测.py、B_真实数据EDA/B_数据探索.py、C_Titanic数据探索/C_Titanic数据探索.py，再运行生成Word报告.py。也可执行一键运行.py。脚本以自身位置定位数据，从其他工作目录启动也可运行。原始B/C数据不被改写；重复运行会刷新统计表、图表与报告。')
p('A：模拟数据、真实注入异常、全部检测结果、混淆矩阵及箱线图。B：原始/清洗数据、缺失与异常记录、描述统计、相关系数、帕累托统计及4张图。C：原始训练集、分组人数/死亡/生存率、所有字段缺失、交叉统计、票价候选及7张图。D：12类问题及优先级完整Markdown答案。')
p('验收包含程序退出状态、数据规模、A题真值对照、数据来源摘要、Pareto累计100%、Titanic分组人数守恒、12张图片可解码且尺寸有效，以及Word文档内容和图片数量。完整检查由验证成果.py实际执行，输出验证结果.json。')
assert figure_count == 12
path = ROOT/'第一次数据探索_完整作业报告.docx'
doc.save(path)
reopened = Document(path)
assert len(reopened.inline_shapes) == 12
assert len(reopened.tables) == table_count
print(json.dumps({'Word文件':str(path), '图片数':figure_count, '表格数':table_count}, ensure_ascii=False))
