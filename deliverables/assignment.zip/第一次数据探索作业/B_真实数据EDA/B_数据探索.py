"""B：真实钻石价格数据的完整探索；原始数据不被覆盖。"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 公共工具 import 设置绘图, 保存图, 保存表, 保存结果, 保存概况
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
设置绘图()
raw = pd.read_csv(ROOT / '原始数据.csv')
保存概况(raw, ROOT / '数据概况.txt')
保存表(raw.head(), ROOT / '前五行.csv', index=False)
numeric = ['carat', 'depth', 'table', 'price', 'x', 'y', 'z']
assert raw.shape == (53940, 10)
assert set(numeric + ['cut', 'color', 'clarity']) == set(raw.columns)
duplicates = int(raw.duplicated().sum())
保存表(raw.loc[raw.duplicated(keep=False)], ROOT / '重复候选记录.csv')
clean = raw.copy()
# 无唯一商品编号，相同属性和报价也可能属于不同钻石，重复候选仅标记。
clean['重复候选'] = raw.duplicated(keep=False)
invalid_counts = {}
# 钻石物理尺寸应为正数，零尺寸不能解释为真实尺寸；记为缺失，不编造填充值。
for col in ['carat', 'depth', 'table', 'price', 'x', 'y', 'z']:
    invalid = clean[col] <= 0
    invalid_counts[col] = int(invalid.sum())
    clean.loc[invalid, col] = np.nan
missing = pd.DataFrame({'原始缺失数': raw.isna().sum(), '原始缺失率%': raw.isna().mean() * 100,
                        '处理后缺失数': clean[raw.columns].isna().sum(),
                        '处理后缺失率%': clean[raw.columns].isna().mean() * 100})
保存表(missing, ROOT / '缺失值统计.csv')
iqr_rows = []
flags = pd.DataFrame(index=clean.index)
for col in numeric:
    q1, q3 = clean[col].quantile([.25, .75])
    iqr = q3 - q1
    low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    flag = (clean[col] < low) | (clean[col] > high)
    flags[col + '_IQR候选'] = flag
    iqr_rows.append({'字段': col, 'Q1': q1, 'Q3': q3, 'IQR': iqr, '下界': low, '上界': high,
                     '异常候选数': int(flag.sum()), '有效样本数': int(clean[col].notna().sum())})
保存表(pd.DataFrame(iqr_rows), ROOT / 'IQR异常统计.csv', index=False)
保存表(pd.concat([raw, flags], axis=1).loc[flags.any(axis=1)], ROOT / '异常候选记录.csv')
clean['任一IQR异常候选'] = flags.any(axis=1)
保存表(clean, ROOT / '清洗后数据.csv', index=False)
desc = clean[numeric].describe().T
desc['median'] = clean[numeric].median()
desc['skew'] = clean[numeric].skew()
保存表(desc, ROOT / '描述性统计.csv')
# 所有相关系数使用同一组完整案例，避免每个格子样本量不同。
complete = clean[numeric].dropna()
corr = complete.corr(method='pearson')
保存表(corr, ROOT / 'Pearson相关系数.csv')
labels = ['重量/克拉', '总深度/%', '台面宽度/%', '价格/美元', '长/mm', '宽/mm', '深/mm']
plt.figure(figsize=(9, 7))
sns.heatmap(corr, annot=True, fmt='.2f', cmap='RdBu_r', vmin=-1, vmax=1,
            square=True, xticklabels=labels, yticklabels=labels)
plt.title(f'B：钻石数值属性Pearson相关（完整案例n={len(complete):,}）')
保存图(ROOT / '相关系数热力图.png')
# 没有交易数量，采用切工类别的记录数，明确不能称为销售额或市场份额。
counts = clean['cut'].value_counts().sort_values(ascending=False)
pareto = pd.DataFrame({'记录数': counts, '占比%': counts / counts.sum() * 100,
                       '累计占比%': counts.cumsum() / counts.sum() * 100})
保存表(pareto, ROOT / '切工帕累托统计.csv')
fig, ax = plt.subplots(figsize=(9, 5))
x = np.arange(len(counts))
ax.bar(x, counts, color='#4f91b5')
ax.set_xticks(x, counts.index)
ax.set_xlabel('切工类别（按记录数降序）')
ax.set_ylabel('钻石记录数')
for i, value in enumerate(counts): ax.text(i, value + 180, f'{value:,}', ha='center', fontsize=9)
ax2 = ax.twinx()
ax2.plot(x, pareto['累计占比%'], color='#c94b4b', marker='o', label='累计占比')
ax2.axhline(80, color='#777777', linestyle='--', label='80%参考线')
ax2.set_ylim(0, 112)
ax2.set_ylabel('累计占比（%）')
ax2.grid(False)
ax2.legend(loc='center right')
plt.title('B：切工类别记录数帕累托图（不是销售额）')
保存图(ROOT / '帕累托图.png')
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
sns.histplot(clean['price'], bins=45, ax=axes[0], color='#4f91b5')
axes[0].set(title='钻石价格分布', xlabel='价格（美元）', ylabel='记录数')
sns.boxplot(data=clean, x='cut', y='price', order=counts.index.tolist(), ax=axes[1], color='#8bb9cf')
axes[1].set(title='不同切工类别的价格分布', xlabel='切工类别', ylabel='价格（美元）')
保存图(ROOT / '价格分布与箱线图.png')
fig, ax = plt.subplots(figsize=(8, 5))
hb = ax.hexbin(clean['carat'], clean['price'], gridsize=45, mincnt=1, bins='log', cmap='viridis')
fig.colorbar(hb, ax=ax, label='网格内记录数（对数色标）')
ax.set(xlabel='重量（克拉）', ylabel='价格（美元）', title='B：重量与价格的密度分布')
保存图(ROOT / '重量与价格关系.png')
k80 = int(np.searchsorted(pareto['累计占比%'].to_numpy(), 80) + 1)
bad_rows = int(raw[['x', 'y', 'z']].le(0).any(axis=1).sum())
conclusion = (
 f'本次探索53,940条真实钻石价格记录，原始表无缺失；{bad_rows}条记录含零尺寸，已改记缺失。'
 f'{duplicates}条完全重复候选因无商品编号而保留。价格中位数为{clean.price.median():.0f}美元，'
 f'均值为{clean.price.mean():.0f}美元，呈右偏。完整案例中重量与价格相关系数为{corr.loc["carat", "price"]:.3f}。'
 f'IQR标记价格候选{int(flags["price_IQR候选"].sum())}条，但高价不等于错误。'
 f'切工前{k80}类累计占{pareto.iloc[k80-1]["累计占比%"]:.1f}%。样本类别占比不是市场份额，相关不能证明因果。'
 '数据为价格横截面，缺少成交量和抽样框，不能推断整体零售市场。')
(ROOT / '约200字分析结论.txt').write_text(conclusion, encoding='utf-8')
summary = {'形状': list(raw.shape), '完全重复候选数': duplicates,
 '零尺寸记录数': bad_rows, '非正值字段数': invalid_counts, '完整案例数': len(complete),
 '任一IQR候选数': int(flags.any(axis=1).sum()), '价格IQR候选数': int(flags['price_IQR候选'].sum()),
 '价格均值': float(clean.price.mean()), '价格中位数': float(clean.price.median()),
 '重量价格相关': float(corr.loc['carat', 'price']), '达到80%的类别数': k80,
 '结论': conclusion, '结论字符数': len(conclusion)}
assert len(clean) == len(raw) and np.isclose(pareto['累计占比%'].iloc[-1], 100)
assert corr.shape == (7, 7) and clean[numeric].dropna().gt(0).all().all()
保存结果(summary, ROOT / '分析摘要.json')
print(summary)
