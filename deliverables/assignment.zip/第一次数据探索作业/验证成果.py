"""核查真正生成的统计结果、图像、Word和数据来源，不用空文件充数。"""
from pathlib import Path
import hashlib
import json
import zipfile
import numpy as np
import pandas as pd
from PIL import Image
from docx import Document

ROOT = Path(__file__).resolve().parent
A, B, C = [ROOT / folder for folder in ['A_异常值检测','B_真实数据EDA','C_Titanic数据探索']]
sources = json.loads((ROOT/'数据来源.json').read_text())
for key in ['B','C','字体']:
    item = sources[key]
    assert hashlib.sha256((ROOT/item['文件']).read_bytes()).hexdigest() == item['sha256']
a = pd.read_csv(A/'模拟数据.csv', index_col=0)
sa = json.loads((A/'分析摘要.json').read_text())
q1, q3 = a['数值'].quantile([.25,.75])
flag = (a['数值'] < q1-1.5*(q3-q1)) | (a['数值'] > q3+1.5*(q3-q1))
assert len(a) == 305 and a['真实异常'].sum() == 5
assert a.index[flag].tolist() == sa['检测当前行索引']
assert a.index[a['真实异常']].tolist() == sa['真实异常当前行索引']
assert int((flag & a['真实异常']).sum()) == sa['真正例'] == 5
assert int((flag & ~a['真实异常']).sum()) == sa['假正例'] == 4
assert int((~flag & a['真实异常']).sum()) == sa['漏检'] == 0
assert set(a['原始行索引']) == set(range(305))
detected = pd.read_csv(A/'异常值检测结果.csv', index_col=0)
assert detected.index.tolist() == a.index[flag].tolist()
assert np.allclose(detected['数值'], a.loc[flag,'数值'])
b = pd.read_csv(B/'原始数据.csv')
clean = pd.read_csv(B/'清洗后数据.csv')
sb = json.loads((B/'分析摘要.json').read_text())
assert b.shape == (53940,10) and len(clean) == len(b)
assert b.duplicated().sum() == sb['完全重复候选数']
assert b[['x','y','z']].le(0).any(axis=1).sum() == sb['零尺寸记录数'] == 20
assert clean['z'].isna().sum() == 20
pareto = pd.read_csv(B/'切工帕累托统计.csv', index_col=0)
counts = b['cut'].value_counts().sort_values(ascending=False)
assert pareto.index.tolist() == counts.index.tolist()
assert np.array_equal(pareto['记录数'].values, counts.values)
assert np.allclose(pareto['累计占比%'], counts.cumsum()/len(b)*100)
assert np.isclose(pareto['累计占比%'].iloc[-1],100)
corr = pd.read_csv(B/'Pearson相关系数.csv', index_col=0)
numeric = ['carat','depth','table','price','x','y','z']
assert np.allclose(corr.values, clean[numeric].dropna().corr().values)
assert np.isclose(clean.price.mean(), sb['价格均值'])
assert 180 <= len(sb['结论']) <= 240
c = pd.read_csv(C/'train.csv')
sc = json.loads((C/'分析摘要.json').read_text())
assert c.shape == (891,12) and c.PassengerId.is_unique
assert c.Survived.sum() == sc['生存人数'] == 342
assert np.isclose(c.Survived.mean(), sc['总体生存率'])
for col, file in [('Sex','性别生存统计.csv'),('Pclass','舱位生存统计.csv')]:
    result = pd.read_csv(C/file, index_col=0)
    direct = c.groupby(col).Survived.agg(['size','sum','mean'])
    assert np.array_equal(result['样本数'], direct['size'])
    assert np.array_equal(result['生存人数'], direct['sum'])
    assert np.allclose(result['生存率'], direct['mean'])
    assert (result['死亡人数']+result['生存人数']).equals(result['样本数'])
age = pd.read_csv(C/'年龄组生存统计.csv', index_col=0)
assert age['样本数'].sum() + sc['年龄缺失数'] == len(c)
assert sc['年龄缺失数'] == c.Age.isna().sum() == 177
assert sc['船舱号缺失数'] == c.Cabin.isna().sum() == 687
images = list(ROOT.glob('*/*.png'))
assert len(images) == 12
assert len(list(A.glob('*.png'))) == 1 and len(list(B.glob('*.png'))) == 4 and len(list(C.glob('*.png'))) == 7
sizes = {}
for path in images:
    with Image.open(path) as im:
        assert min(im.size) >= 500
        sizes[str(path.relative_to(ROOT))] = list(im.size)
        im.verify()
word = ROOT/'第一次数据探索_完整作业报告.docx'
with zipfile.ZipFile(word) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.startswith('word/media/')]) == 12
    assert b'PAGE' in z.read('word/footer1.xml')
doc = Document(word)
assert len(doc.inline_shapes) == 12 and len(doc.tables) >= 25
body = '\n'.join(p.text for p in doc.paragraphs)
for text in ['A  基础题', 'B  数据分析题', 'C  挑战题', 'D  思维题', sb['结论']]:
    assert text in body
assert '、'.join(map(str,sa['检测当前行索引'])) in body
d = (ROOT/'D_电商数据质量分析/D_思考题答案.md').read_text()
assert len([line for line in d.splitlines() if line.startswith('| P')]) == 12
files = [p for p in ROOT.rglob('*') if p.is_file() and '.cache' not in p.parts and '__pycache__' not in p.parts]
assert all(p.stat().st_size > 0 for p in files), '存在空文件'
for name in ['A.log','B.log','C.log','Word.log']:
    path = ROOT/'运行记录'/name
    if path.exists():
        log = path.read_text()
        assert 'Traceback' not in log and 'Glyph' not in log
result = {'状态':'通过','A':'305条；TP=5，FP=4，FN=0；索引和数值一致',
 'B':'53940条；缺失处理、相关矩阵和帕累托累计占比验证通过',
 'C':'891条；342人生存；分组人数和比率与原始数据一致',
 'D':'12种潜在问题，含影响、检测、处理与优先级',
 '图表数量':len(images), '图像尺寸':sizes, 'Word图片数':len(doc.inline_shapes),
 'Word表格数':len(doc.tables), 'Word检查':'DOCX压缩结构、XML、页码、正文、表格和图片可读取；未使用桌面Word逐页渲染',
 '来源文件SHA256':'全部一致'}
(ROOT/'验证结果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
